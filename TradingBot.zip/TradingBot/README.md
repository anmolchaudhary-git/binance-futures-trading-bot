# Binance Futures Testnet Trading Bot

## Description

A Python based CLI trading bot for Binance Futures Testnet.

## Features

- Market Orders
- Limit Orders
- BUY / SELL Support
- Account Balance Check
- Order Management
- Logging
- Error Handling

## Installation

Install required packages:
## Configuration

Create a `.env` file:
## Run

Show help:
## Example

Market Order:
Limit Order:
## Author

Anmol Chaudhary